﻿/*************************************************************
** File: FirstProgram.cs
** Author/s: Justin Rough
** Description:
**     A simple program used to introduce the basic structure
**     of a C# application.
*************************************************************/
using System;

namespace FirstProgram
{
    class FirstProgram
    {
        // Main function, where the program’s execution begins
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to OO Development!");
        }
    }
}