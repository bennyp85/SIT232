﻿/*************************************************************
** File: InputOutput.cs
** Author/s: Justin Rough
** Description:
**     A program that prompts the user to enter in contact
**     information (family name, given name, title, country of
**     birth, and spoken languages) and then displays the
**     information in a formatted report.
*************************************************************/
using System;

namespace InputOutput
{
    class InputOutput
    {
        static void Main(string[] args)
        {
            Console.Write("What is your family name? ");
            string familyName = Console.ReadLine();

            Console.Write("What is your given name? ");
            string givenName = Console.ReadLine();

            Console.Write("What is your title (Mr, Mrs, Miss, Ms, etc.)? ");
            string title = Console.ReadLine();

            Console.Write("What is your country of birth? ");
            string country = Console.ReadLine();

            Console.Write("What languages do you speak? ");
            string languages = Console.ReadLine();

            Console.WriteLine("**************************************************");
            Console.WriteLine("     Field \tValue");
            Console.WriteLine("**************************************************");
            Console.WriteLine("      Name:\t{0} {1} {2}", title, givenName, familyName);
            Console.WriteLine("   Born In:\t{0}", country);
            Console.WriteLine("    Speaks:\t{0}", languages);
            Console.WriteLine("**************************************************");
        }
    }
}